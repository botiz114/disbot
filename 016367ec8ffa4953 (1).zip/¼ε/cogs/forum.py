import discord
import api
import asyncio
from discord import app_commands
from discord.ui import *
from discord.ext import commands
from discord.ext.commands import has_permissions 
from logger import *
logger = logging.getLogger("bot")

cookies = ''
user_agent = ''
api.setup(user_agent, cookies)
class forum(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
    @commands.Cog.listener()
    async def on_ready(self):
        print('[SYSTEM]: форума успешно загружена ✅')

    @app_commands.command(name= "закрыть", description="Закрыть/Открыть тему")
    @app_commands.describe(link = 'Укажите ссылку на тему')
    async def close(self, interaction: discord.Interaction, link: str):
        api.close_thread(link)
        await interaction.response.send_message('<:1113171098192842762:1151936128560148570> | `Установил теме новый статус (Закрыто/Открыто)`')

    @app_commands.command(name= "закрепить", description="Заккрепить/Открепить тему")
    @app_commands.describe(link = 'Укажите ссылку на тему')
    async def pin(self, interaction: discord.Interaction, link: str):
        api.pin_thread(link)
        await interaction.response.send_message('<:1113172842515800124:1151936179118280724> | `Установил теме новый статус (Закреплено/Откреплено)`')

    @app_commands.command(name= "префикс", description="Установить префикс в тему")
    @app_commands.choices(prefix=[
        app_commands.Choice(name="На рассмотрении", value="На рассмотрении"),
        app_commands.Choice(name="Рассмотрено", value="Рассмотрено"),
        app_commands.Choice(name="Отказано", value="Отказано")
        ])
    @app_commands.describe(link = 'Укажите ссылку на тему')
    @app_commands.describe(prefix = 'Укажите префикс')
    async def prefix(self, interaction: discord.Interaction, link: str, prefix: app_commands.Choice[str]):
        if prefix.name == "На рассмотрении": pref = 15
        elif prefix.name == "Рассмотрено": pref = 17
        elif prefix.name == "Отказано": pref = 18
        result = api.get_thread(link)
        title = result[0]
        title = title.replace("Рассмотрено", "") 
        title = title.replace("Отказано", "")
        title = title.replace("На рассмотрении", "") 
        trt = api.set_prefix(link, pref, title)
        await interaction.response.send_message(f'<:1113174883111800884:1151936177528635503> | `Установил префикс теме [{prefix.name}]`')

    @app_commands.command(name= "переместить", description="Переместить тему в корзину")
    @app_commands.describe(link = 'Укажите ссылку на тему')
    async def move(self, interaction: discord.Interaction, link: str):
        api.get_move(link)
        await interaction.response.send_message('<:1113174883111800884:1151936177528635503> | `Тема перемещена в корзину`')
async def setup(bot):
    await bot.add_cog(forum(bot))