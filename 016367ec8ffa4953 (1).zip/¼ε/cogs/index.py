
import asyncio
import discord
import psutil as ps
from discord import ui
from discord.ext import commands
import os
import datetime
import pymongo
from pymongo import MongoClient
from discord import ui, app_commands
from multiprocessing import connection
from logger import *
logger = logging.getLogger("bot")

cll = MongoClient("")
acc=cll.mob.tok

class dobav(ui.Modal, title='Заполните форму для получения жетона'):
    nick = discord.ui.TextInput(label='Ник Нейм',style = discord.TextStyle.short) 
    org = discord.ui.TextInput(label='Организация',style = discord.TextStyle.short)
    async def on_submit(self, interaction: discord.Interaction):
        if acc.count_documents({'user_id': interaction.user.id}) == 1:
            return await interaction.response.send_message(f'`[WARNING] У вас есть уже жетон!`', ephemeral=True)
        for i in acc.find().sort("_id", pymongo.DESCENDING).limit(1):
            number=i['_id']+1
        post = {
            'user_id': interaction.user.id,
            '_id': number,
            'nick': self.nick.value,
            'dolz': self.org.value
        }
        acc.insert_one(post)
        nick = acc.find_one({'user_id': interaction.user.id})['nick']
        org = acc.find_one({'user_id': interaction.user.id})['dolz']
        numb = acc.find_one({'user_id': interaction.user.id})['_id']
        embed = discord.Embed(title='',description=f':bust_in_silhouette: Сотрудник: {interaction.user.mention}\n:identification_card: Имя сотрудника: `{nick}`\n:file_folder: Должность: `{org}`\n:dividers: Бейджик: `{numb}`' )
        await interaction.response.send_message(embed=embed, ephemeral=True)

class up(ui.Modal, title='Заполните форму для обновления жетона'):
    nick = discord.ui.TextInput(label='Ник Нейм',style = discord.TextStyle.short) 
    org = discord.ui.TextInput(label='Организация',style = discord.TextStyle.short)
    async def on_submit(self, interaction: discord.Interaction):
        acc.update_one({'user_id': interaction.user.id}, {"$set": {"nick":  f'{self.nick.value}'}})
        acc.update_one({'user_id': interaction.user.id}, {"$set": {"dolz":  f'{self.org.value}'}})
        await interaction.response.send_message('`[WARNING] Ваш жетон обновлен в БД`', ephemeral=True)

class info(ui.Modal, title='Получения информации о жетоне'):
    num = discord.ui.TextInput(label='Номер жетона',style = discord.TextStyle.short) 
    async def on_submit(self, interaction: discord.Interaction):
        if acc.count_documents({"_id": int(self.num.value)}) == 0:
            await interaction.response.send_message('`[WARNING] Данного жетона нету в БД`', ephemeral=True)
        else:
            id = acc.find_one({"_id": int(self.num.value)})['_id']
            nick = acc.find_one({"_id": int(self.num.value)})['nick']
            dolz = acc.find_one({"_id": int(self.num.value)})['dolz']
            user = acc.find_one({"_id": int(self.num.value)})['user_id']
            embed = discord.Embed(description=f':bust_in_silhouette: Информация о сотруднике: <@{user}>\n:identification_card: Имя сотрудника: `{nick}`\n:file_folder: Должность: `{dolz}`\n:dividers: Номер бейджика: `{id}`')
            embed.set_author(name=f'{interaction.guild.name}', icon_url = interaction.guild.icon)
            await interaction.response.send_message(embed = embed,  ephemeral=True)

class teh_message(discord.ui.View):  
    def __init__(self) -> None:
        super().__init__(timeout=None)
        self.value = None
    @discord.ui.button(emoji="🗂", label="Получить жетон",style=discord.ButtonStyle.grey,custom_id='teh_message:discord')
    async def bbb(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(dobav())
    @discord.ui.button(emoji="👨‍💻", label="Обновить жетон",style=discord.ButtonStyle.grey,custom_id='teh_message:you')
    async def aaa(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(up())
    @discord.ui.button(emoji="💾", label="Посмотреть жетон",style=discord.ButtonStyle.grey,custom_id='teh_message:badge')
    async def ссс(self, interaction: discord.Interaction, button: discord.ui.Button):
        if acc.count_documents({'user_id': interaction.user.id}) == 0:
            return await interaction.response.send_message('`[WARNING] Вашего жетона нету в БД`', ephemeral=True)
        else:
            nick = acc.find_one({'user_id': interaction.user.id}).get('nick', 'None')
            org = acc.find_one({'user_id': interaction.user.id})['dolz']
            numb = acc.find_one({'user_id': interaction.user.id})['_id']
            embed = discord.Embed(title='',description=f':bust_in_silhouette: Сотрудник: {interaction.user.mention}\n:identification_card: Имя сотрудника: `{nick}`\n:file_folder: Должность: `{org}`\n:dividers: Бейджик: `{numb}`' )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    @discord.ui.button(emoji="🔎", label="Информация о жетоне",style=discord.ButtonStyle.grey,custom_id='teh_message:info')
    async def rrr(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(info())

class tiket(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.add_view(teh_message())
    @commands.Cog.listener()
    async def on_ready(self):
        print('[SYSTEM]: репорта успешно загружена!')



    @commands.command(name= "badge_up")
    async def badge_up(self,ctx):
        embed = discord.Embed(description="```В данной форме при получение жетона необходимо указать\nНик Нейм:\nДолжность:``` ```Допустимые должности предоставлены ниже. Их необходимо указывать при получение/обновление жетона.\n\nСотрудник FBI\nСотрудник LSPD\nСотрудник SWAT\nСотрудник SFPD\nСотрудник RCSD\nСотрудник Прокуратуры```")
        await ctx.send(embed=embed,view=teh_message())

async def setup(bot):
    await bot.add_cog(tiket(bot))
