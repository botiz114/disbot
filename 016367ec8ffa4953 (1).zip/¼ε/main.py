import discord
import asyncio
import json
import psutil
from discord import app_commands
from discord.ui import *
from discord.ext import commands
from discord.ext.commands import has_permissions 
from pymongo import MongoClient
import pymongo
import os
from logger import *
logger = logging.getLogger("bot")

cll = MongoClient()
s=cll.mob.tok

bot = commands.Bot(command_prefix='/', intents=discord.Intents.all()) # задаем префикс боту
bot.remove_command('help') # удаляем команду хелп

@bot.event # создаем событие
async def on_ready(): # бот зашел в сеть
    print('[SYSTEM]: основной файл успешно запущена!') 
    logger.info(f"User: {bot.user} (ID {bot.user.id})")
    # await bot.change_presence(status=discord.Status.online, activity=discord.Game('Слежка за Модерацией')) # создаем активность боту
    await bot.tree.sync()

async def load():
    for filename in os.listdir("./cogs"):
        if filename.endswith(".py"):
            await bot.load_extension(f"cogs.{filename[:-3]}")

async def Mobile():
    await bot.load_extension('jishaku')
    await load()
    await bot.start()

asyncio.run(Mobile())

